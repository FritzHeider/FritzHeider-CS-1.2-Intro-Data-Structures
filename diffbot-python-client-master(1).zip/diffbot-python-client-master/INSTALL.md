Installation
============

To install simply (preferably in a virtualenv):

    $ pip install -r requirements.txt

To run the example:

    $ python example.py